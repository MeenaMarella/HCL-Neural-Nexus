# Insurance Data Warehouse (SQLite)
Beginner-friendly guide: turn raw insurance CSVs into a cleaned, standardized dataset, load it into SQLite, and run labeled A–G analytics queries with one script.

## What You Get
- Reproducible ETL scripts to combine, clean, and standardize raw files.
- A SQLite warehouse (`data/warehouse/insurance.db`) with dimensions and a fact table.
- A labeled SQL script (`sql/sample_queries.sql`) that prints clear, separated outputs for questions A–G.

## Prerequisites
- Python 3.x with `pandas` and `numpy`.
- SQLite CLI (`sqlite3`) available on your PATH.
- Run commands from the repo root: `C:\Users\anith\Desktop\insurance_project`.

## Quick Start (copy-paste in PowerShell)
```
python src/ingest.py
python src/cleaning.py
python src/standardize_cleaned.py
python src/build_database.py
sqlite3 data/warehouse/insurance.db ".read sql/sample_queries.sql"
```
Outputs will be labeled “A) ...” through “G) ...” with headers and column formatting.

## Directory Map
- `data/raw/` – original regional/day CSVs.
- `data/staging/` – combined, cleaned, and standardized CSV outputs.
- `data/warehouse/insurance.db` – SQLite warehouse.
- `reports/` – JSON/CSV summaries from cleaning/standardization.
- `src/` – ETL scripts: `ingest.py`, `cleaning.py`, `standardize_cleaned.py`, `build_database.py`.
- `sql/sample_queries.sql` – labeled A–G queries (sets headers/column mode, prints section labels).

## Step-by-Step ETL
1) **Combine raw to staging**  
   `python src/ingest.py`  
   Creates `data/staging/raw_combined_all.csv` (+ day splits).
2) **Clean & normalize**  
   `python src/cleaning.py`  
   - Coalesces duplicate headers, trims text, parses dates/numbers.  
   - Derives `days_delay` and `row_hash`, drops duplicates.  
   - Outputs `data/staging/cleaned_all.csv` + `reports/cleaning_summary.json`.
3) **Standardize schema (26 canonical columns)**  
   `python src/standardize_cleaned.py`  
   - Aligns to the canonical layout; writes `data/staging/standardized_cleaned_all.csv` (+ day splits).  
   - Summaries in `reports/standardize_summary.json`.
4) **Build the warehouse**  
   `python src/build_database.py`  
   - Creates `data/warehouse/insurance.db` with dims & fact.
5) **Run A–G analytics**  
   `sqlite3 data/warehouse/insurance.db ".read sql/sample_queries.sql"`  
   - Section labels and headers make each answer easy to read.

## Expected Outputs
- Warehouse file: `data/warehouse/insurance.db`
- Reports: `reports/cleaning_summary.json`, `reports/standardize_summary.json`
- Staging CSVs: `data/staging/cleaned_all.csv`, `data/staging/standardized_cleaned_all.csv` (+ day splits)

## Warehouse Model
- `dim_date` – date_id (YYYYMMDD), year, quarter, month, day, day_name, weekofyear.
- `dim_address` – address_id keyed on country/region/state_or_province/city/postal_code.
- `dim_customer` – customer_key, segment, marital_status, gender, dob_id (FK to dim_date), address_id (FK to dim_address).
- `dim_policy` – policy_id, name, type, description, term.
- `fact_policy_payments` – customer_key, policy_id, FKs to date milestones (effective/policy/next premium/actual paid), premiums, `total_policy_amt`, `premium_amt_paid_tilldate`, computed `days_delay`, simple `late_fee_est`, address_id.

## A–G Queries (what they answer)
- **A)** Customers by region (filtered blanks; sorted desc).
- **B)** Policies by policy type (filters junk like “1/0/1900”; sorted desc).
- **C)** Premium + total policy amount by region (filtered blanks; sorted desc).
- **D)** Late payments: avg `days_delay` + estimated late fees (positive delays only).
- **E)** Policies ending within the next year (by `policy_end_date`).
- **F)** Top 10 customers by `premium_amt_paid_tilldate` (non-null; sorted desc).
- **G)** Punctuality by policy type (avg delay, on-time counts; filters junk; sorted by lowest delay).

## Highlights for Reviewers/Examiners
- Clear, labeled query outputs (A–G) with headers/columns enabled.
- Strong cleaning: header normalization, duplicate-column coalescing, type parsing, deduplication.
- Canonical schema alignment across disparate source files.
- Indexed SQLite dims/fact for responsive querying.

## Troubleshooting
- **Python not found**: ensure Python 3 is on PATH (or use `python3`).
- **sqlite3 not found**: install SQLite CLI or use another client to run the SQL script.
- **Missing standardized file**: run the steps in order; the warehouse build expects the standardized CSV.

## Need Sample Outputs?
Run the quick-start block above; the console will show labeled sections for A–G. If you want the latest sample outputs embedded here, re-run and paste, and we can add a short “Example Results” section.